def calc_tax():
    pass


def calc_shipping():
    pass

# Relative import from ..shopping import xyz